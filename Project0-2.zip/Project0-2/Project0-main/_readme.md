# Final Project for Practice of Programming

Group member:
- Jinzhong Gu (team leader)
- Chenyu Li
- Chuanzhi Zhou

## TimeLine

- Document: 0425
- First edition: 0531
- Final edition: 0630

## TODO list

-[] Documentation

## Working Logs (In Progress)
