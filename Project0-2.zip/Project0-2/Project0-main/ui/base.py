from PyQt5.QtWidgets import QWidget


class BasePage(QWidget):
    def on_show(self):
        pass
