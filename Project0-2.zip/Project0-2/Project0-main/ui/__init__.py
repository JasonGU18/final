from .action_library_page import ActionLibraryPage # noqa
from .body_data_page import BodyDataPage# noqa
from .login_page import LoginPage # noqa
from .main_page import MainPage # noqa
from .personalized_workout_page import PersonalizedWorkoutPage # noqa
from .record_page import RecordPage # noqa
from .view_page import ViewPage # noqa