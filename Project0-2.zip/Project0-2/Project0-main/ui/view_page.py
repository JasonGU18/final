from PyQt5.QtWidgets import (
    QLabel, QTextEdit, QPushButton, QVBoxLayout, QHBoxLayout,
    QMessageBox, QCalendarWidget, QWidget
)
from PyQt5.QtCore import QDate
from .base import BasePage
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from data_interface import LiteDataManager  # noqa

# 用于将训练动作映射到部位
muscle_map = {
    "俯卧撑": ["chest", "triceps"],
    "引体向上": ["back", "biceps"],
    "深蹲": ["legs"],
    "仰卧起坐": ["abs"],
    "平板支撑": ["core"]
}

# 定义字符火柴人图案的展示组件
class HumanFigureWidget(QLabel):
    def __init__(self):
        super().__init__()
        self.muscle_parts = set()
        self.setStyleSheet("font-size: 20px;")
        self.update_figure()

    def highlight_parts(self, parts):
        self.muscle_parts = set(parts)
        self.update_figure()

    def update_figure(self):
        # 简单的火柴人，部分字符可以变色以“高亮肌群”
        head = "<font color='red'>O</font>" if "head" in self.muscle_parts else "O"
        chest = "<font color='red'>|</font>" if "chest" in self.muscle_parts else "|"
        arms = "<font color='red'>/</font>" if "triceps" in self.muscle_parts else "/"
        arms += "<font color='red'>\\</font>" if "biceps" in self.muscle_parts else "\\"
        legs = "<font color='red'>/</font>" if "legs" in self.muscle_parts else "/"
        legs += "<font color='red'> \\</font>" if "legs" in self.muscle_parts else " \\"
        abs_core = "<font color='red'>|</font>" if "abs" in self.muscle_parts or "core" in self.muscle_parts else "|"
        back = "<font color='red'>|</font>" if "back" in self.muscle_parts else "|"

        figure = f"""
<pre>
  {head}
 {arms}
  {chest}
  {abs_core}
  {legs}
</pre>
"""
        self.setText(figure)

class ViewPage(BasePage):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.database_manager: LiteDataManager = controller.database_manager

        layout = QVBoxLayout()

        title_label = QLabel("历史训练记录")
        layout.addWidget(title_label)

        # 日历控件
        self.calendar = QCalendarWidget()
        self.calendar.clicked.connect(self.on_date_selected)
        layout.addWidget(self.calendar)

        # 显示当天训练记录的文本区域
        self.text_area = QTextEdit()
        self.text_area.setReadOnly(True)
        layout.addWidget(self.text_area)

        # 人形图案显示
        self.figure_widget = HumanFigureWidget()
        layout.addWidget(self.figure_widget)

        # 按钮区域
        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("刷新记录")
        refresh_btn.clicked.connect(self.load_all_data)

        back_main_btn = QPushButton("返回主界面")
        back_main_btn.clicked.connect(lambda: self.controller.show_page("MainPage"))

        btn_layout.addWidget(refresh_btn)
        btn_layout.addWidget(back_main_btn)
        layout.addLayout(btn_layout)

        self.setLayout(layout)

    def load_all_data(self):
        """加载所有记录，但不显示（内部缓存）"""
        try:
            self.all_data = self.database_manager.get_training_records()
            self.on_date_selected(self.calendar.selectedDate())  # 加载当前日数据
        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载失败: {e}")

    def on_date_selected(self, qdate: QDate):
        self.text_area.clear()
        self.figure_widget.highlight_parts([])  # 清空上次肌群高亮

        date_str = qdate.toString("yyyyMMdd")
        matched = [rec for rec in self.all_data if rec.timestamp == date_str]

        if not matched:
            self.text_area.setPlainText("该日暂无训练记录。")
            return

        output = ""
        trained_parts = set()

        for info in matched:
            output += f"日期: {info.timestamp[:4]}-{info.timestamp[4:6]}-{info.timestamp[6:]}\n"
            for ex, n_group in zip(info.exercises, info.n_group):
                output += f"  - 动作: {ex} | 组数: {n_group}\n"
                trained_parts.update(muscle_map.get(ex, []))
            output += "\n"

        self.text_area.setPlainText(output)
        self.figure_widget.highlight_parts(trained_parts)

    def on_show(self):
        self.load_all_data()
